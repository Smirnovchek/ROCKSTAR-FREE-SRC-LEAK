/*
 * Decompiled with CFR 0.150.
 * 
 * Could not load the following classes:
 *  com.google.common.collect.Lists
 *  org.lwjgl.input.Mouse
 */
package clickgui;

import java.awt.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.List;

import clickgui.panel.component.impl.ModuleComponent;

import net.minecraft.client.renderer.GlStateManager;
import org.lwjgl.input.Mouse;

import com.google.common.collect.Lists;

import clickgui.panel.Panel;
import clickgui.setting.Setting;
import clickgui.setting.SettingsManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Gui;
import net.minecraft.client.gui.GuiScreen;
import net.minecraft.client.gui.ScaledResolution;
import net.minecraft.client.gui.inventory.GuiInventory;
import net.minecraft.util.ResourceLocation;
import smirnov.rockstar.Rockstar;
import smirnov.rockstar.helpers.render.RenderHelper;
import smirnov.rockstar.helpers.render.Translate;
import smirnov.rockstar.module.Category;



public final class ClickGuiScreen extends GuiScreen {
    private static ClickGuiScreen INSTANCE;

    private final List panels = Lists.newArrayList();

    public Translate translate;

    public static double scaling;

    private float curAlpha;

    public ClickGuiScreen() {
        Category[] category = Category.values();
        scaling = 0.0D;
        for (int i = category.length - 1; i >= 0; i--) {
            this.panels.add(new Panel(category[i], 5 + 104 * i, 10));
            this.translate = new Translate(0.0F, 0.0F);
        }
    }

    public void drawScreen(int mouseX, int mouseY, float partialTicks) {
        int i = 0;
        if (this.mc.player != null && this.mc.world != null) {
            ScaledResolution sr = new ScaledResolution(Minecraft.getMinecraft());
            float alpha = 150.0F;
            int step = (int)(alpha / 100.0F);
            if (this.curAlpha < alpha - step) {
                this.curAlpha += step;
            } else if (this.curAlpha > alpha - step && this.curAlpha != alpha) {
                this.curAlpha = (int)alpha;
            } else if (this.curAlpha != alpha) {
                this.curAlpha = (int)alpha;
            }
            Color c = new Color(Rockstar.getClientColor().getRed(), Rockstar.getClientColor().getGreen(), Rockstar.getClientColor().getBlue(), (int)this.curAlpha);
            Color none = new Color(0, 0, 0, 0);

            if(Rockstar.instance.settingsManager.getSettingByName("Shadow").getValBoolean()) {
                this.drawDefaultBackground();
            }
            if(Rockstar.instance.settingsManager.getSettingByName("GradientBackGround").getValBoolean()) {
                drawGradientRect(0, 0, sr.getScaledWidth(), sr.getScaledHeight(), c.getRGB(), none.getRGB());
            }
            if(Rockstar.instance.settingsManager.getSettingByName("ESPpreview").getValBoolean()) {
            	int x = Rockstar.instance.settingsManager.getSettingByName("ESPpreview X").getValInt();
            	int y = Rockstar.instance.settingsManager.getSettingByName("ESPpreview Y").getValInt();
            	int size = Rockstar.instance.settingsManager.getSettingByName("ESPpreview Size").getValInt();
            	GuiInventory.drawEntityOnScreen((int) x + 135, (int) y + 30, size, 15, 15, mc.player);
            }
            for (int panelsSize = this.panels.size(); i < panelsSize; i++) {
                ((Panel)this.panels.get(i)).onDraw(mouseX, mouseY);
                updateMouseWheel();
            }
        }
    }

    public void updateMouseWheel() {
        int i = 0;
        int scrollWheel = Mouse.getDWheel();
        for (int panelsSize = this.panels.size(); i < panelsSize; i++) {
            if (scrollWheel < 0) {
                ((Panel)this.panels.get(i)).setY(((Panel)this.panels.get(i)).getY() - 15);
            } else if (scrollWheel > 0) {
                ((Panel)this.panels.get(i)).setY(((Panel)this.panels.get(i)).getY() + 15);
            }
        }
    }

    protected void mouseClicked(int mouseX, int mouseY, int mouseButton) throws IOException {
        int i = 0;
        ScaledResolution scaledResolution = new ScaledResolution(this.mc);
        for (int panelsSize = this.panels.size(); i < panelsSize; i++)
            ((Panel)this.panels.get(i)).onMouseClick(mouseX, mouseY, mouseButton);
        super.mouseClicked(mouseX, mouseY, mouseButton);
    }

    protected void mouseReleased(int mouseX, int mouseY, int state) {
        int i = 0;
        for (int panelsSize = this.panels.size(); i < panelsSize; i++)
            ((Panel)this.panels.get(i)).onMouseRelease(mouseX, mouseY, state);
    }

    public void onGuiClosed() {
        if (this.mc.entityRenderer.isShaderActive())
            this.mc.entityRenderer.theShaderGroup = null;
    }

    public void initGui() {
        if (Rockstar.instance.settingsManager.getSettingByName("Blur").getValBoolean()) {
            if (!this.mc.gameSettings.ofFastRender &&
                    !this.mc.entityRenderer.isShaderActive())
                this.mc.entityRenderer.loadShader(new ResourceLocation("shaders/post/blur.json"));
        }
    }
    protected void keyTyped(char typedChar, int keyCode) throws IOException {
        int i = 0;
        for (int panelsSize = this.panels.size(); i < panelsSize; i++)
            ((Panel)this.panels.get(i)).onKeyPress(typedChar, keyCode);
        super.keyTyped(typedChar, keyCode);
    }
}