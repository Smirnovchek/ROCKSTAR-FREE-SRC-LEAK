/*
` * Decompiled with CFR 0.150.
 */
package clickgui.panel;

public enum AnimationState {
    RETRACTING,
    EXPANDING,
    STATIC;

}

