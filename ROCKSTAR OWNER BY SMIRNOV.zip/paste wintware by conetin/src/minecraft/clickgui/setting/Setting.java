package clickgui.setting;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import smirnov.rockstar.module.Feature;

/**
 *  Made by HeroCode
 *  it's free to use
 *  but you have to credit me
 *
 *  @author HeroCode
 */
public class Setting {
	
	public String activeMode;
	private String name;
	private Feature parent;
	private String mode;
	
	private String sval;
	private ArrayList<String> options;
	
	private boolean bval;
	
	private double dval;
	private double min;
    private String[] valueNumeric;
    public String[] values;
    private String id;

	private double max;
    private boolean enabled;
	private boolean onlyint = false;
	private Supplier<Boolean> visibility;
	
	public Setting(String name, Feature parent, String sval, ArrayList<String> options) {
        this.name = name;
        this.parent = parent;
        this.enabled = enabled;
        this.sval = sval;
        this.id = id;

        this.valueNumeric = values;

        this.options = options;
        this.mode = "Combo";
        this.visibility = () -> true;
    }

    public Setting(String name, Feature parent, boolean bval) {
        this.name = name;
        this.parent = parent;
        this.id = id;

        this.bval = bval;
        this.valueNumeric = values;

        this.enabled = enabled;
        this.mode = "Check";
        this.visibility = () -> true;
    }

    public Setting(String name, Feature parent) {
        this.name = name;
        this.parent = parent;
        this.id = id;

        this.mode = "Mass";
        this.valueNumeric = values;

        this.enabled = enabled;
        this.visibility = () -> true;
    }

    public Setting(String name, Feature parent, double dval, double min, double max, boolean onlyint) {
        this.name = name;
        this.parent = parent;
        this.dval = dval;
        this.min = min;
        this.enabled = enabled;
        this.valueNumeric = values;

        this.max = max;
        this.id = id;

        this.onlyint = onlyint;
        this.mode = "Slider";
        this.visibility = () -> true;
    }

    public Setting(String name, Feature parent, double dval, double min, double max) {
        this.name = name;
        this.parent = parent;
        this.dval = dval;
        this.valueNumeric = values;

        this.min = min;
        this.enabled = enabled;
        this.max = max;
        this.id = id;

        this.mode = "HueSlider";
        this.visibility = () -> true;
    }

    public Setting(String name, Feature parent, double dval, double min, double max, int fix) {
        this.name = name;
        this.parent = parent;
        this.dval = dval;
        this.id = id;

        this.min = min;
        this.max = max;
        this.enabled = enabled;
        this.valueNumeric = values;

        this.mode = "BrightNessSlider";
        this.visibility = () -> true;
    }

    public Setting(String name, Feature parent, double dval, double min, double max, String fix) {
        this.name = name;
        this.parent = parent;
        this.dval = dval;
        this.id = id;

        this.valueNumeric = values;

        this.min = min;
        this.enabled = enabled;
        this.max = max;

        this.mode = "SaturationSlider";
        this.visibility = () -> true;
    }
	
	public String getName(){
		return name;
	}
	
	public Feature getParentMod(){
		return parent;
	}
	

    public boolean getValue() {
        return this.enabled;
    }
	
	public String getValString(){
		return this.sval;
	}
	
	public void setValString(String in){
		this.sval = in;
	}
	
    public int getValInt() {
        if (this.onlyint) {
            this.dval = (int) dval;
        }
        return (int) this.dval;
    }
	
    public void setValFloat(float in) {
        this.dval = in;
    }
    
    public boolean isVisible() {
        return visibility.get();
    }
	
	public ArrayList<String> getOptions(){
		return this.options;
	}
	
	public boolean getValBoolean(){
		return this.bval;
	}
	
	public void setValBoolean(boolean in){
		this.bval = in;
	}
	
	public double getValDouble(){
		if(this.onlyint){
			this.dval = (int)dval;
		}
		return this.dval;
	}
	
    public float getValFloat() {
        if (this.onlyint) {
            this.dval = (int)this.dval;
        }
        return (float)this.dval;
    }

	public void setValDouble(double in){
		this.dval = in;
	}
	
	public boolean isHueSlider() {
        return this.mode.equalsIgnoreCase("HueSlider");
    }

    public boolean isBrightSlider() {
        return this.mode.equalsIgnoreCase("BrightNessSlider");
    }

    public boolean isSaturationSlider() {
        return this.mode.equalsIgnoreCase("SaturationSlider");
    }

    public boolean isCheck() {
        return this.mode.equalsIgnoreCase("Check");
    }

    public boolean isSlider() {
        return this.mode.equalsIgnoreCase("Slider");
    }
    
	public double getMin(){
		return this.min;
	}
	
	public double getMax(){
		return this.max;
	}

    public boolean isMass() {
        return this.mode.equalsIgnoreCase("Mass");
    }
	
	public boolean isCombo(){
		return this.mode.equalsIgnoreCase("Combo") ? true : false;
	}
	
	public boolean onlyInt(){
		return this.onlyint;
	}

	public void setValue(boolean in) {
        this.enabled = in;
    }

	  public String[] getValueNumeric() {
	        return valueNumeric;
	    }

	    public void setValueNumeric(String[] valueNumeric) {
	        this.valueNumeric = valueNumeric;
	    }

	    public String getId() {
	        return id;
	    }

	    public String[] getValues() {
	        return values;
	    }

	    public List<String> getSelectedValues() {
	        return getSelectedValues();
	    }

	
}
