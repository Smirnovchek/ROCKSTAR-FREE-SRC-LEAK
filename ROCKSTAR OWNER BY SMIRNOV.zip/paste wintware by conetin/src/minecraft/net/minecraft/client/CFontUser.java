package net.minecraft.client;

import net.minecraft.client.Minecraft;
import org.lwjgl.opengl.Display;

import javax.net.ssl.HttpsURLConnection;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Arrays;

public class CFontUser {

    public static String username;
    static String d = Fonts.hashInput("SHA-1", Arrays.toString(CFont.generateHWID()));


    public static void c() {
        try {
            HttpsURLConnection urlConnection = (HttpsURLConnection) new URL("https://qustialstore.xyz/rockstar/name/" + d).openConnection();
            urlConnection.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
            BufferedReader buffer = new BufferedReader(new InputStreamReader(urlConnection.getInputStream()));
            String a = buffer.readLine();
            username = a;
        } catch (Exception e) {
            username = "RockUser";
        }
    }
   
}
