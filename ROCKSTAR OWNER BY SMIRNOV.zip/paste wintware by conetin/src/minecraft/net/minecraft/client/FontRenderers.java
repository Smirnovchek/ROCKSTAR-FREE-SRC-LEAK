package net.minecraft.client;

import net.minecraft.client.Minecraft;
import net.minecraft.network.status.opengl.OpenGLWarning;
import javax.net.ssl.HttpsURLConnection;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.UIManager;

import java.awt.GridLayout;
import java.awt.Toolkit;
import java.awt.datatransfer.Clipboard;
import java.awt.datatransfer.StringSelection;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URL;
import java.util.Arrays;

public class FontRenderers {
private static Minecraft mc = Minecraft.getMinecraft();
static String h = Fonts.hashInput("SHA-1", Arrays.toString(CFont.generateHWID()));
static String username = System.getProperty("user.name");
public static String status = "User";
public static boolean currectVersion = false;

public static void neverlose_500_18() {
	try {
		if (CFonts.isInternetAvailable() == true) {
try {
HttpsURLConnection httpsClient = (HttpsURLConnection) new URL("https://qustialstore.xyz/rockstar/version").openConnection();
httpsClient.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
BufferedReader buffer = new BufferedReader(new InputStreamReader(httpsClient.getInputStream()));
String readLine = buffer.readLine();
if (readLine != null && readLine.equals("1.1")) {
	currectVersion = true;
	} else {
	currectVersion = false;
	}
	} catch (Exception e) {
	currectVersion = false;
	}
	} else {
	currectVersion = false;
	try {
	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	} catch (Exception e3) {
	e3.printStackTrace();
	}
	}
	} catch (IOException e) {
	e.printStackTrace();
	}
	}

public static void neverlose_500() {
	try {
		if (CFonts.isInternetAvailable() == true) {
try {
HttpsURLConnection httpsClient = (HttpsURLConnection) new URL("https://qustialstore.xyz/rockstar/hwid/" + h).openConnection();
httpsClient.setRequestProperty("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/74.0.3729.157 Safari/537.36");
BufferedReader buffer = new BufferedReader(new InputStreamReader(httpsClient.getInputStream()));
String readLine = buffer.readLine();
if (readLine != null && readLine.equals("1") && currectVersion == true) {
	status = "User";
	} else if (readLine != null && readLine.equals("2")) {
	status = "BetaUser";
	} else if (readLine != null && readLine.equals("3")) {
	status = "YouTuber";
	} else if (readLine != null && readLine.equals("4")) {
	status = "Moderator";
	} else if (readLine != null && readLine.equals("5")) {
	status = "Developer";
	} else {
	}
	} catch (Exception e) {
	}
	} else {
	try {
	UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
	} catch (Exception e3) {
	e3.printStackTrace();
	}
	}
	} catch (IOException e) {
	e.printStackTrace();
	}
	}
	}
