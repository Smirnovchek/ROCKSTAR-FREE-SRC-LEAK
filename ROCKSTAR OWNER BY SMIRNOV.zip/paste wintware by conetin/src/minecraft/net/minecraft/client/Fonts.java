package net.minecraft.client;

import java.security.MessageDigest;

public class Fonts {

    public static String hashInput(String hash, String input) {
        StringBuilder sb = new StringBuilder();
        try {
            MessageDigest messageDigest = MessageDigest.getInstance(hash);
            byte[] bytes = messageDigest.digest(input.getBytes());

            for (byte dig : bytes) {
                sb.append(Integer.toString((dig & 0xFF) + 256, 16).substring(1));
            }
        } catch (Exception e) {
        }
        return sb.toString();
    }

}
